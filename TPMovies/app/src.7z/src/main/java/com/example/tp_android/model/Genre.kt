package com.example.tp_android.model


data class Genre(
    val id: Int,
    val name: String
)