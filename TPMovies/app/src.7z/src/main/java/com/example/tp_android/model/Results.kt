package com.example.tp_android.model

data class Results (val page: Int, val results: List<Movie>){
}