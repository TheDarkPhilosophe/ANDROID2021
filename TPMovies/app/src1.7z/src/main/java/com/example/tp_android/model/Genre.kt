package com.example.tp_android.model


import com.google.gson.annotations.SerializedName

data class Genre(
    val id: Int,
    val name: String
)